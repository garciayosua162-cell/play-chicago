import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js';

const canvas=document.querySelector('#game');
const scene=new THREE.Scene();
scene.background=new THREE.Color(0x91a7b8);
scene.fog=new THREE.Fog(0x91a7b8,90,360);

const camera=new THREE.PerspectiveCamera(65,innerWidth/innerHeight,.1,700);
const renderer=new THREE.WebGLRenderer({canvas,antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));
renderer.setSize(innerWidth,innerHeight);
renderer.shadowMap.enabled=true;
renderer.shadowMap.type=THREE.PCFSoftShadowMap;

const hemi=new THREE.HemisphereLight(0xb9d7ef,0x30343a,1.7); scene.add(hemi);
const sun=new THREE.DirectionalLight(0xffffff,2.0); sun.position.set(-80,130,70); sun.castShadow=true; sun.shadow.mapSize.set(1024,1024); scene.add(sun);

const mats={
 road:new THREE.MeshStandardMaterial({color:0x25272a,roughness:.86}),
 sidewalk:new THREE.MeshStandardMaterial({color:0x777777,roughness:.92}),
 grass:new THREE.MeshStandardMaterial({color:0x3d6042,roughness:1}),
 water:new THREE.MeshStandardMaterial({color:0x24536b,roughness:.28,metalness:.15}),
 glass:new THREE.MeshStandardMaterial({color:0x52788b,roughness:.25,metalness:.3}),
 white:new THREE.MeshStandardMaterial({color:0xe4e1d8,roughness:.75}),
 dark:new THREE.MeshStandardMaterial({color:0x20242a,roughness:.65}),
 brick:new THREE.MeshStandardMaterial({color:0x7b4d3e,roughness:.9})
};

function box(x,y,z,mat,px=0,py=0,pz=0){
 const m=new THREE.Mesh(new THREE.BoxGeometry(x,y,z),mat);m.position.set(px,py,pz);m.castShadow=true;m.receiveShadow=true;scene.add(m);return m;
}
function cylinder(r,h,mat,x,y,z){
 const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,h,12),mat);m.position.set(x,y,z);m.castShadow=true;scene.add(m);return m;
}

// Ground and Chicago-inspired street grid
box(520,1,520,mats.grass,0,-.5,0);
for(let i=-220;i<=220;i+=44){
 box(13,.08,520,mats.road,i,.04,0);
 box(520,.08,13,mats.road,0,.045,i);
 for(let k=-230;k<230;k+=24){
   box(2,.10,9,mats.white,i-.0,.10,k);
   box(9,.10,2,mats.white,k,.10,i);
 }
}

// Sidewalk strips
for(let i=-220;i<=220;i+=44){
 box(4,.15,520,mats.sidewalk,i-8.5,.12,0); box(4,.15,520,mats.sidewalk,i+8.5,.12,0);
 box(520,.15,4,mats.sidewalk,0,.12,i-8.5); box(520,.15,4,mats.sidewalk,0,.12,i+8.5);
}

// Buildings, varied heights
for(let x=-198;x<=198;x+=44) for(let z=-198;z<=198;z+=44){
 if(Math.abs(x)<30 && Math.abs(z)<30) continue;
 const h=10+Math.random()*42;
 const w=28+Math.random()*7, d=28+Math.random()*7;
 const mat=Math.random()>.35?mats.white:mats.brick;
 box(w,h,d,mat,x,h/2,z);
 // windows
 for(let yy=5;yy<h-2;yy+=6){
   for(let xx=-w/2+4;xx<w/2-2;xx+=7) box(1.5,2.4,.12,mats.glass,x+xx,yy,z-d/2-.08);
 }
}

// Downtown towers
for(const [x,z,h] of [[0,-88,105],[44,-88,82],[-44,-88,70],[88,-44,76],[-88,-44,66],[88,0,92],[-88,0,84]]){
 box(28,h,28,mats.dark,x,h/2,z);
 for(let y=6;y<h;y+=7) box(20,2,.15,mats.glass,x,y,z-14.1);
}

// Lakefront
box(120,0.3,520,mats.water,260,.08,0);

// Trees
for(let x=-210;x<=210;x+=22) for(let z=-210;z<=210;z+=22){
 if(Math.random()>.72 && Math.abs(x%44)>10 && Math.abs(z%44)>10){
  cylinder(.65,4,mats.dark,x,2,z); cylinder(2.8,5,mats.grass,x,6,z);
 }
}

// Elevated train
box(8,5,500,mats.dark,-110,6,0);
for(let z=-240;z<=240;z+=22) box(10,1,3,mats.dark,-110,3.2,z);

// Cars
const carMats=[new THREE.MeshStandardMaterial({color:0x9a3030}),new THREE.MeshStandardMaterial({color:0x2d4d73}),new THREE.MeshStandardMaterial({color:0xb8b9b4}),new THREE.MeshStandardMaterial({color:0x242629})];
for(let i=0;i<34;i++){
 const horizontal=Math.random()>.5;
 const x=horizontal?(Math.random()*440-220):(Math.round((Math.random()*10-5))*44+Math.random()*8-4);
 const z=horizontal?(Math.round((Math.random()*10-5))*44+Math.random()*8-4):(Math.random()*440-220);
 const c=new THREE.Group();
 const body=box(5.2,1.4,2.4,carMats[i%4]); body.position.set(0,.9,0); body.castShadow=true;c.add(body);
 const roof=box(2.7,1,2.0,mats.dark);roof.position.set(0,1.9,0);c.add(roof);
 c.position.set(x,0,z); if(horizontal)c.rotation.y=Math.PI/2; scene.add(c);
}

// Player
const player=new THREE.Group();
const body=new THREE.Mesh(new THREE.CapsuleGeometry(.55,1.25,5,10),new THREE.MeshStandardMaterial({color:0x15171b}));
body.position.y=1.35;body.castShadow=true;player.add(body);
const head=new THREE.Mesh(new THREE.SphereGeometry(.48,16,12),new THREE.MeshStandardMaterial({color:0x9b694d}));
head.position.y=2.55;head.castShadow=true;player.add(head);
const cap=new THREE.Mesh(new THREE.CylinderGeometry(.52,.52,.18,16),new THREE.MeshStandardMaterial({color:0x111111}));
cap.position.y=2.9;cap.castShadow=true;player.add(cap);
scene.add(player); player.position.set(0,0,15);

const npcs=[];
for(let i=0;i<18;i++){
 const n=new THREE.Group();
 const b=new THREE.Mesh(new THREE.CapsuleGeometry(.38,.9,4,8),new THREE.MeshStandardMaterial({color:new THREE.Color().setHSL(Math.random(),.45,.38)}));b.position.y=1.0;n.add(b);
 const h=new THREE.Mesh(new THREE.SphereGeometry(.34,12,8),new THREE.MeshStandardMaterial({color:0x9b694d}));h.position.y=1.95;n.add(h);
 n.position.set(Math.random()*360-180,0,Math.random()*360-180);scene.add(n);npcs.push({o:n,a:Math.random()*6.28});
}

// Rain
const rainN=1200, pos=new Float32Array(rainN*3);
for(let i=0;i<rainN;i++){pos[i*3]=Math.random()*440-220;pos[i*3+1]=Math.random()*130;pos[i*3+2]=Math.random()*440-220}
const rg=new THREE.BufferGeometry();rg.setAttribute('position',new THREE.BufferAttribute(pos,3));
const rain=new THREE.Points(rg,new THREE.PointsMaterial({color:0xbfd8e8,size:.16,transparent:true,opacity:.65}));
scene.add(rain);

// Controls
let joyX=0,joyY=0,running=false,firstPerson=false;
const joy=document.querySelector('#joy'),stick=document.querySelector('#stick');
function setJoy(e){const r=joy.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const max=45;const len=Math.hypot(dx,dy);if(len>max){dx*=max/len;dy*=max/len}stick.style.transform=`translate(${dx}px,${dy}px)`;joyX=dx/max;joyY=dy/max}
joy.addEventListener('pointerdown',e=>{joy.setPointerCapture(e.pointerId);setJoy(e)});
joy.addEventListener('pointermove',e=>{if(e.buttons)setJoy(e)});
joy.addEventListener('pointerup',()=>{joyX=joyY=0;stick.style.transform='translate(0,0)'});
document.querySelector('#run').addEventListener('pointerdown',()=>running=true);
document.querySelector('#run').addEventListener('pointerup',()=>running=false);
document.querySelector('#cam').onclick=()=>firstPerson=!firstPerson;
const keys={};addEventListener('keydown',e=>keys[e.key.toLowerCase()]=true);addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);

let t=0;
function animate(){
 requestAnimationFrame(animate);t+=.016;
 let x=joyX,y=joyY;
 if(keys.w)x=0,y=-1;if(keys.s)y=1;if(keys.a)x=-1;if(keys.d)x=1;
 const speed=running||keys.shift?9:5;
 const dir=new THREE.Vector3(x,0,y);
 if(dir.length()>0){
  dir.normalize(); player.position.x+=dir.x*speed*.016;player.position.z+=dir.z*speed*.016;
  player.rotation.y=Math.atan2(dir.x,dir.z);
 }
 // NPC wandering
 npcs.forEach(n=>{n.a+=Math.sin(t*.3+n.a)*.002;n.o.position.x+=Math.cos(n.a)*.012;n.o.position.z+=Math.sin(n.a)*.012});
 // Rain falls
 const a=rg.attributes.position.array;
 for(let i=1;i<a.length;i+=3){a[i]-=.9;if(a[i]<0)a[i]=120+Math.random()*30}rg.attributes.position.needsUpdate=true;
 // Camera
 if(firstPerson){
  camera.position.lerp(new THREE.Vector3(player.position.x,2.55,player.position.z),.18);
  camera.rotation.copy(player.rotation);
  camera.lookAt(player.position.x+Math.sin(player.rotation.y)*8,2.4,player.position.z+Math.cos(player.rotation.y)*8);
 }else{
  const back=new THREE.Vector3(0,3.4,6.5).applyAxisAngle(new THREE.Vector3(0,1,0),player.rotation.y);
  camera.position.lerp(player.position.clone().add(back),.12);
  camera.lookAt(player.position.x,1.5,player.position.z);
 }
 renderer.render(scene,camera);
}
animate();
setTimeout(()=>document.querySelector('#loading').classList.add('loading-hide'),900);
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
